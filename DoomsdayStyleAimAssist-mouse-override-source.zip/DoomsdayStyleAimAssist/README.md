# Doomsday-style AimAssist (Fabric 1.21.11)

Java 21 / Fabric client mod source. This is an experimental implementation, not a verified release.

## Implemented in this source
- Client tick target scan for other visible players; excludes self, UUID Friends List and teammates.
- Weapon filter for swords, axes, mace and spear identifiers.
- FOV, range and tracking speed settings.
- Closest point on the target bounding box, with a ray-hit dead zone to stop pulling once the crosshair ray intersects the target.
- Shield behavior toggle.
- Middle-click a player while they are under the crosshair to add/remove them from Friends List.
- Properties persistence in `config/doomsday-style-aimassist.properties`.
- Mod Menu settings screen and toggle keybinds.
- GitHub Actions workflow to build and upload the JAR artifact.

## Important limitations
- This project has **not been compiled or tested in a Minecraft 1.21.11 runtime here**. Fabric/Yarn APIs and the mixin signature must be confirmed by the first GitHub Actions build.
- The current `No Ignore Mouse` option is exposed and persisted, but vanilla tick-based camera adjustment already happens alongside normal mouse input; it does not yet implement raw mouse-delta weighting.
- Legit Aim currently reduces tracking strength; it is not a sophisticated motion model.
- The UI uses click-to-cycle values, not draggable sliders.
- Spear detection uses item IDs ending in `_spear`; verify the exact item IDs in the target game/modpack.
- Team exclusion uses Minecraft's teammate relation. Servers with custom team plugins may not expose team membership to the client.
- The mod only affects the local client camera. It does not change server hitboxes or guarantee hits.

## Build locally
Install JDK 21 and Gradle, then run:
```sh
gradle build
```
The first build needs internet access to download Loom and Minecraft/Fabric dependencies.

## Build on GitHub
1. Create a repository and upload the **contents** of this folder (so `build.gradle` is at repository root).
2. Push to `main` or `master`.
3. Open **Actions** and wait for `Build Fabric mod` to finish.
4. Download the `doomsday-style-aimassist` artifact from the successful workflow run. The runnable mod is the non-`sources` JAR inside `build/libs`.

If the workflow fails, open the failed job log and share the first `error:` / `Could not resolve` section for correction.
