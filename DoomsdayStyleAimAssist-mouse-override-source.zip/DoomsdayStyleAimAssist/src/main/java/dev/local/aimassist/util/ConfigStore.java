package dev.local.aimassist.util;

import dev.local.aimassist.AimConfig;
import dev.local.aimassist.FriendsList;
import net.minecraft.client.MinecraftClient;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;

public final class ConfigStore {
    private ConfigStore() {}
    private static Path path() { return MinecraftClient.getInstance().runDirectory.toPath().resolve("config/doomsday-style-aimassist.properties"); }

    public static void load(AimConfig c, FriendsList f) {
        Path p = path();
        if (!Files.exists(p)) return;
        Properties v = new Properties();
        try (Reader r = Files.newBufferedReader(p)) {
            v.load(r);
            c.enabled = Boolean.parseBoolean(v.getProperty("enabled", "false"));
            c.noIgnoreMouse = Boolean.parseBoolean(v.getProperty("noIgnoreMouse", "true"));
            c.legitAim = Boolean.parseBoolean(v.getProperty("legitAim", "true"));
            c.onlyWeapon = Boolean.parseBoolean(v.getProperty("onlyWeapon", "true"));
            c.aimWhileShielding = Boolean.parseBoolean(v.getProperty("aimWhileShielding", "false"));
            c.trackingSpeed = Double.parseDouble(v.getProperty("trackingSpeed", "0.22"));
            c.activationFov = Double.parseDouble(v.getProperty("activationFov", "30"));
            c.maxRange = Double.parseDouble(v.getProperty("maxRange", "3"));
            Set<UUID> ids = new HashSet<>();
            String raw = v.getProperty("friends", "");
            if (!raw.isBlank()) for (String id : raw.split(",")) try { ids.add(UUID.fromString(id)); } catch (IllegalArgumentException ignored) {}
            f.replace(ids);
        } catch (Exception e) { System.err.println("[Doomsday AimAssist] Could not load config: " + e.getMessage()); }
    }

    public static void save(AimConfig c, FriendsList f) {
        Path p = path();
        try {
            Files.createDirectories(p.getParent());
            Properties v = new Properties();
            v.setProperty("enabled", Boolean.toString(c.enabled));
            v.setProperty("noIgnoreMouse", Boolean.toString(c.noIgnoreMouse));
            v.setProperty("legitAim", Boolean.toString(c.legitAim));
            v.setProperty("onlyWeapon", Boolean.toString(c.onlyWeapon));
            v.setProperty("aimWhileShielding", Boolean.toString(c.aimWhileShielding));
            v.setProperty("trackingSpeed", Double.toString(c.trackingSpeed));
            v.setProperty("activationFov", Double.toString(c.activationFov));
            v.setProperty("maxRange", Double.toString(c.maxRange));
            v.setProperty("friends", String.join(",", f.snapshot().stream().map(UUID::toString).toList()));
            try (Writer w = Files.newBufferedWriter(p)) { v.store(w, "Doomsday-style AimAssist"); }
        } catch (Exception e) { System.err.println("[Doomsday AimAssist] Could not save config: " + e.getMessage()); }
    }
}
