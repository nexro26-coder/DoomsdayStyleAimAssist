package dev.local.aimassist.mixin;

import dev.local.aimassist.AimAssistClient;
import dev.local.aimassist.util.ConfigStore;
import net.minecraft.client.Mouse;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public abstract class MouseMixin {
    @Inject(method = "onMouseButton", at = @At("TAIL"))
    private void doomsday$middleClickFriend(long window, int button, int action, int mods, CallbackInfo ci) {
        if (button != GLFW.GLFW_MOUSE_BUTTON_MIDDLE || action != GLFW.GLFW_PRESS) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.currentScreen != null) return;
        if (client.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof PlayerEntity target
                && target != client.player) {
            boolean added = AimAssistClient.FRIENDS.toggle(target.getUuid());
            ConfigStore.save(AimAssistClient.CONFIG, AimAssistClient.FRIENDS);
            client.player.sendMessage(net.minecraft.text.Text.literal(
                (added ? "§aĐã thêm " : "§eĐã xóa ") + target.getName().getString() + " khỏi Friends List"
            ), true);
        }
    }
}
