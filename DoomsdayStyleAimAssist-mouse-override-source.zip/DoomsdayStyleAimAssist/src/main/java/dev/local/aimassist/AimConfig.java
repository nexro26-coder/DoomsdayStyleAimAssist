package dev.local.aimassist;

public final class AimConfig {
    public boolean enabled = false;
    public boolean noIgnoreMouse = true;
    public boolean legitAim = true;
    public boolean onlyWeapon = true;
    public boolean aimWhileShielding = false;
    public double trackingSpeed = 0.22;
    public double activationFov = 30.0;
    public double maxRange = 3.0;

    public boolean isSupportedWeapon(String itemId) {
        if (itemId == null) return false;
        return itemId.endsWith("_sword") || itemId.endsWith("_axe")
            || itemId.equals("minecraft:mace") || itemId.endsWith("_spear");
    }

    public double clampedTrackingSpeed() { return Math.max(0.01, Math.min(1.0, trackingSpeed)); }
    public double clampedFov() { return Math.max(1.0, Math.min(180.0, activationFov)); }
    public double clampedRange() { return Math.max(1.0, Math.min(6.0, maxRange)); }
}
