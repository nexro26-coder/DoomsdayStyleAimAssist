package dev.local.aimassist;

import dev.local.aimassist.core.AimController;
import dev.local.aimassist.util.ConfigStore;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class AimAssistClient implements ClientModInitializer {
    public static final AimConfig CONFIG = new AimConfig();
    public static final FriendsList FRIENDS = new FriendsList();

    private static KeyBinding toggleAim, toggleLegit, toggleNoIgnore, toggleWeapon, toggleShield;

    @Override
    public void onInitializeClient() {
        ConfigStore.load(CONFIG, FRIENDS);
        toggleAim = register("toggle_aim", GLFW.GLFW_KEY_R);
        toggleLegit = register("toggle_legit", GLFW.GLFW_KEY_UNKNOWN);
        toggleNoIgnore = register("toggle_no_ignore_mouse", GLFW.GLFW_KEY_UNKNOWN);
        toggleWeapon = register("toggle_only_weapon", GLFW.GLFW_KEY_UNKNOWN);
        toggleShield = register("toggle_shield_mode", GLFW.GLFW_KEY_UNKNOWN);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            boolean changed = false;
            while (toggleAim.wasPressed()) { CONFIG.enabled = !CONFIG.enabled; changed = true; }
            while (toggleLegit.wasPressed()) { CONFIG.legitAim = !CONFIG.legitAim; changed = true; }
            while (toggleNoIgnore.wasPressed()) { CONFIG.noIgnoreMouse = !CONFIG.noIgnoreMouse; changed = true; }
            while (toggleWeapon.wasPressed()) { CONFIG.onlyWeapon = !CONFIG.onlyWeapon; changed = true; }
            while (toggleShield.wasPressed()) { CONFIG.aimWhileShielding = !CONFIG.aimWhileShielding; changed = true; }
            if (changed) ConfigStore.save(CONFIG, FRIENDS);
            AimController.tick(client);
        });
    }

    private static KeyBinding register(String name, int key) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.doomsday_style_aimassist." + name,
            InputUtil.Type.KEYSYM, key, KeyBinding.Category.MISC
        ));
    }
}
