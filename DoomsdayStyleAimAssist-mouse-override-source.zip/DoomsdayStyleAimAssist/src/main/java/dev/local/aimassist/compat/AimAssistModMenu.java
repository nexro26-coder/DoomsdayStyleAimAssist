package dev.local.aimassist.compat;

import dev.local.aimassist.AimAssistClient;
import dev.local.aimassist.util.ConfigStore;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

public final class AimAssistModMenu implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> new AimAssistConfigScreen(parent);
    }
}
