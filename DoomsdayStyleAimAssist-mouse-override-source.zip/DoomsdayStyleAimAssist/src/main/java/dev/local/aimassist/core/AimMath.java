package dev.local.aimassist.core;

import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class AimMath {
    private AimMath() {}

    public static Vec3d closestPoint(Vec3d origin, Box box) {
        return new Vec3d(
            MathHelper.clamp(origin.x, box.minX, box.maxX),
            MathHelper.clamp(origin.y, box.minY, box.maxY),
            MathHelper.clamp(origin.z, box.minZ, box.maxZ)
        );
    }

    public static double wrap(double degrees) { return MathHelper.wrapDegrees(degrees); }

    public static float approach(float current, float target, double factor) {
        return (float)(current + wrap(target - current) * MathHelper.clamp(factor, 0.0, 1.0));
    }

    public static float yawTo(Vec3d from, Vec3d to) {
        Vec3d d = to.subtract(from);
        return (float)(Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
    }

    public static float pitchTo(Vec3d from, Vec3d to) {
        Vec3d d = to.subtract(from);
        double horizontal = Math.sqrt(d.x * d.x + d.z * d.z);
        return (float)-Math.toDegrees(Math.atan2(d.y, horizontal));
    }

    public static double angularDistance(float yawA, float pitchA, float yawB, float pitchB) {
        double dy = wrap(yawB - yawA);
        double dp = pitchB - pitchA;
        return Math.sqrt(dy * dy + dp * dp);
    }
}
