package dev.local.aimassist.compat;

import dev.local.aimassist.AimAssistClient;
import dev.local.aimassist.AimConfig;
import dev.local.aimassist.util.ConfigStore;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class AimAssistConfigScreen extends Screen {
    private final Screen parent;
    private int row;
    public AimAssistConfigScreen(Screen parent) {
        super(Text.literal("Doomsday AimAssist"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        row = 0;
        AimConfig c = AimAssistClient.CONFIG;
        addToggle("AimAssist", () -> c.enabled, v -> c.enabled = v);
        addToggle("Legit Aim", () -> c.legitAim, v -> c.legitAim = v);
        addToggle("No Ignore Mouse", () -> c.noIgnoreMouse, v -> c.noIgnoreMouse = v);
        addToggle("Only Weapon", () -> c.onlyWeapon, v -> c.onlyWeapon = v);
        addToggle("Aim khi đỡ khiên", () -> c.aimWhileShielding, v -> c.aimWhileShielding = v);
        addValue("Tracking Speed", () -> c.trackingSpeed, v -> c.trackingSpeed = v, 0.05, 1.0, 0.05);
        addValue("Activation FOV", () -> c.activationFov, v -> c.activationFov = v, 5, 120, 5);
        addValue("Range", () -> c.maxRange, v -> c.maxRange = v, 1, 6, 0.5);
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> {
            ConfigStore.save(c, AimAssistClient.FRIENDS);
            close();
        }).dimensions(width / 2 - 100, height - 28, 200, 20).build());
    }

    private interface Getter { boolean get(); }
    private interface Setter { void set(boolean value); }
    private void addToggle(String label, Getter getter, Setter setter) {
        addDrawableChild(ButtonWidget.builder(toggleText(label, getter.get()), b -> {
            setter.set(!getter.get());
            b.setMessage(toggleText(label, getter.get()));
            ConfigStore.save(AimAssistClient.CONFIG, AimAssistClient.FRIENDS);
        }).dimensions(width / 2 - 120, 34 + row++ * 25, 240, 20).build());
    }

    private interface DoubleGetter { double get(); }
    private interface DoubleSetter { void set(double value); }
    private void addValue(String label, DoubleGetter getter, DoubleSetter setter, double min, double max, double step) {
        addDrawableChild(ButtonWidget.builder(valueText(label, getter.get()), b -> {
            double next = getter.get() + step;
            if (next > max + 1e-6) next = min;
            setter.set(next);
            b.setMessage(valueText(label, next));
            ConfigStore.save(AimAssistClient.CONFIG, AimAssistClient.FRIENDS);
        }).dimensions(width / 2 - 120, 34 + row++ * 25, 240, 20).build());
    }

    private static Text toggleText(String label, boolean value) {
        return Text.literal(label + ": " + (value ? "ON" : "OFF"));
    }
    private static Text valueText(String label, double value) {
        return Text.literal(label + ": " + String.format(java.util.Locale.ROOT, "%.2f", value));
    }

    @Override
    public void close() { if (client != null) client.setScreen(parent); }
}
