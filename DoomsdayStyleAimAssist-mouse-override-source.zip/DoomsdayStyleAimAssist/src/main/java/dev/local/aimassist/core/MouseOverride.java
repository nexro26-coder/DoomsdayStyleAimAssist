package dev.local.aimassist.core;

/**
 * Temporarily suspends aim assistance after real cursor movement.
 * The timer is refreshed while the cursor continues moving, so assistance
 * resumes only after the user has stopped moving the mouse for the delay.
 */
public final class MouseOverride {
    private static volatile long resumeAtNanos;
    private static double lastX;
    private static double lastY;
    private static boolean initialized;

    private MouseOverride() {}

    public static synchronized void onCursorMove(double x, double y) {
        if (!initialized) {
            lastX = x;
            lastY = y;
            initialized = true;
            return;
        }

        double dx = x - lastX;
        double dy = y - lastY;
        lastX = x;
        lastY = y;

        // Any actual cursor movement pauses the assist; ignore sub-pixel noise.
        if (Math.abs(dx) > 0.01 || Math.abs(dy) > 0.01) {
            long delayMillis = dev.local.aimassist.AimAssistClient.CONFIG.mouseResumeDelayMs;
            resumeAtNanos = System.nanoTime() + Math.max(0L, delayMillis) * 1_000_000L;
        }
    }

    public static boolean isPaused() {
        return System.nanoTime() < resumeAtNanos;
    }

    public static synchronized void reset() {
        initialized = false;
        resumeAtNanos = 0L;
    }
}
