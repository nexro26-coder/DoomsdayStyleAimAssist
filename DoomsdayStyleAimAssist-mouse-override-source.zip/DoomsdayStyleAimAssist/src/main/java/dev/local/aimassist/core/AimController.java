package dev.local.aimassist.core;

import dev.local.aimassist.AimAssistClient;
import dev.local.aimassist.AimConfig;
import dev.local.aimassist.FriendsList;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ShieldItem;
import net.minecraft.registry.Registries;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public final class AimController {
    private AimController() {}

    public static void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || client.currentScreen != null) return;

        AimConfig cfg = AimAssistClient.CONFIG;
        FriendsList friends = AimAssistClient.FRIENDS;
        if (!cfg.enabled || !hasAllowedItem(player, cfg)) return;
        if (!cfg.aimWhileShielding && player.isUsingItem()
            && player.getActiveItem().getItem() instanceof ShieldItem) return;

        double range = cfg.clampedRange();
        PlayerEntity best = null;
        Vec3d bestPoint = null;
        double bestScore = Double.MAX_VALUE;
        Vec3d eye = player.getEyePos();

        Box search = player.getBoundingBox().expand(range);
        for (PlayerEntity candidate : client.world.getEntitiesByClass(
                PlayerEntity.class, search,
                p -> p != player && p.isAlive() && !friends.contains(p.getUuid())
                    && !player.isTeammate(p) && player.canSee(p))) {
            double distance = player.distanceTo(candidate);
            if (distance > range) continue;

            Vec3d point = AimMath.closestPoint(eye, candidate.getBoundingBox());
            float targetYaw = AimMath.yawTo(eye, point);
            float targetPitch = AimMath.pitchTo(eye, point);
            double angle = AimMath.angularDistance(player.getYaw(), player.getPitch(), targetYaw, targetPitch);
            if (angle > cfg.clampedFov() * 0.5) continue;

            // Prefer a target near the crosshair; distance is a small tie-breaker.
            double score = angle + distance * 0.015;
            if (score < bestScore) {
                bestScore = score;
                best = candidate;
                bestPoint = point;
            }
        }
        if (best == null || bestPoint == null) return;

        // If the current view ray already intersects the target hitbox, do not pull away.
        Vec3d end = eye.add(player.getRotationVec(1.0F).multiply(range + 0.15));
        if (best.getBoundingBox().raycast(eye, end).isPresent()) return;

        float desiredYaw = AimMath.yawTo(eye, bestPoint);
        float desiredPitch = AimMath.pitchTo(eye, bestPoint);
        double factor = cfg.clampedTrackingSpeed();
        if (cfg.legitAim) factor *= 0.65;

        // A tiny dead zone prevents jitter around the edge of the hitbox.
        if (AimMath.angularDistance(player.getYaw(), player.getPitch(), desiredYaw, desiredPitch) < 0.12) return;
        player.setYaw(AimMath.approach(player.getYaw(), desiredYaw, factor));
        player.setPitch((float)net.minecraft.util.math.MathHelper.clamp(
            player.getPitch() + (desiredPitch - player.getPitch()) * factor, -90.0, 90.0));
    }

    private static boolean hasAllowedItem(ClientPlayerEntity player, AimConfig cfg) {
        if (!cfg.onlyWeapon) return true;
        String id = Registries.ITEM.getId(player.getMainHandStack().getItem()).toString();
        return cfg.isSupportedWeapon(id);
    }
}
