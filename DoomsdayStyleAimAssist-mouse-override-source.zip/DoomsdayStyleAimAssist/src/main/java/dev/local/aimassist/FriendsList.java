package dev.local.aimassist;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class FriendsList {
    private final Set<UUID> friends = new HashSet<>();
    public boolean toggle(UUID id) {
        if (id == null) return false;
        if (friends.remove(id)) return false;
        friends.add(id);
        return true;
    }
    public boolean contains(UUID id) { return id != null && friends.contains(id); }
    public Set<UUID> snapshot() { return Collections.unmodifiableSet(new HashSet<>(friends)); }
    public void replace(Set<UUID> ids) { friends.clear(); friends.addAll(ids); }
}
